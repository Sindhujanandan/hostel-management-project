// 1.Ways to print in JavaScript
// console.log("hello world");
// alert("me");
// document.write("this is document write")

// 2.Javascript console API

// console.log("hello world",4+6,"Another log");
// console.warn("this is warning");
// console.error("This is an error");

// 3.variables
// var number1=34;
// var number2=56;

// console.log(number1+number2);


// 4.Data types in JavaScript

// String
// var str="this is a string";
// var str2="this is also a string";
// console.log(str1,str2);

// Number
// var num1=57;
// var num2=79;
// console.log(num1,num2);

// Boolean
// var bol=true;
// var bol2=false;
// console.log(bol,bol2);

// Objects
// var marks={
//     Shruti:64,
//     Simran:78,
//     Sindhuja:85
// }
// console.log(marks);

// undefined
// var und=undefined;
// console.log(und);

// NUll
// var n=null;
// console.log(n);

// At a very high level, there are two types of data types in javaScript
// 1.Primitive Data Types:undefined, null, number,string,boolean,symbol.
// 2.Reference Data Types:Arrays and Objects

// Arrays
// var arr=[1,2,3,4,5];
// console.log(arr);

// var a=34;
// var b=4;
// function
// DRY-Do not repeat yourself
// function avg(a,b)
// {
//     c=(a+b)/2;
//     return c;
// }
// c1=avg(4,6);
// c2=avg(7,9);
// console.log(c1,c2);

// var age=19;
// if(age>18)
// {
//     console.log('you can drink rasna water');
// }
// else{
//     console.log('you can not drink water');
// }

// var arr=[1,2,3,4,5,6,7,8,9];
// for(var i=0;i<arr.length;i++)
// {
//     console.log(arr[i]);
// }

// for each
// arr.forEach(function(element)
// {
//     console.log(element);
// })
// let j=0;
// while(j<arr.length)
// {
//     console.log(arr[j]);
//     j++;
// }

// Arrays Methods
// let myArr=["fan","camera",34,null,true];
// console.log(myArr.length);
// myArr.pop();
// console.log(myArr.length);
// myArr.push("sindhuja");
// myArr.shift();

// const newLen=myArr.unshift("Harry");
// console.log(newLen);
// console.log(myArr);
// Strings Methods in JavaScript

// let myLovelyString="Sindhuja You need to become a bold girl";
// console.log(myLovelyString.length);
// console.log(myLovelyString.indexOf("bold"));

// console.log(myLovelyString.slice(0,39));
//  d = myLovelyString.replace("need","should");
//  console.log(d,myLovelyString);
// console.log(myLovelyString.lastIndexOf("bold"));

//  let myDate=new Date();
//  console.log(myDate);
// console.log(myDate.getTime());
// console.log(myDate.getFullYear());
// console.log(myDate.getMonth());
// console.log(myDate.getDate());
// console.log(myDate.getHours());
// console.log(myDate.getMinutes());

// DOM Manipulation---document object Model
// let elem=document.getElementById('click');
// console.log(elem);

// let elemClass=document.getElementsByClassName("container")
// console.log(elemClass);
// // elemClass[0].style.background="yellow";
// elemClass[0].classList.add("bg-primary");
// console.log(elem.innerHTML);
// console.log(elem.innerText);

// console.log(elemClass[0].innerHTML);
// console.log(elemClass[0].innerText);

// tn=document.getElementsByTagName("div");
// console.log(tn);
// createdElement=document.createElement('p');
// createdElement.innerText="This is a created para";
// tn[0].appendChild(createdElement);
// createdElement2=document.createElement('b');
// createdElement2.innerText="This is a created bold";
// tn[0].replaceChild(createdElement2,createdElement);
// removeChild(Element);

// Selecting Using Query
// sel=document.querySelector('.container');
// console.log(sel);
// sel2=document.querySelectorAll('.container');
// console.log(sel2);

// Events in JavaScript
// function clicked()
// {
//     console.log('The bottom was clicked');
// }
// window.onload=function(){
//     console.log('The document was loaded');
// }
// firstContainer.addEventListener('click',function()
// {
//     document.querySelectorAll('.container')[1].innerHTML="<b> we have clicked </b>"
//     console.log("Clicked on container");
// })

// firstContainer.addEventListener('mouseover',function()
// {
//     console.log("Mouse on container");
// })

// firstContainer.addEventListener('mouseout',function()
// {
//     console.log("Mouse out of container");
// })

// let prevHTML= document.querySelectorAll('.container')[1].innerHTML;
// firstContainer.addEventListener('mouseup',function()
// {
//     document.querySelectorAll('.container')[1].innerHTML=prevHTML;
//     console.log("Mouse up when clicked on container");
// })

// firstContainer.addEventListener('mousedown',function()
// {
//     document.querySelectorAll('.container')[1].innerHTML="<b> we have clicked </b>"
//     console.log("Mouse down when clicked on container");
// })

// Arrow Functions
// function summ(a,b)
// {
//     return a+b;
// }

// summ=(a,b)=>{
//     return a+b;
// }

// logKaro =()=>{
//     console.log("I am your log");
// }
// SetTimeout and setinterval
// document.querySelectorAll('.container')[1].innerHTML="<b> Set interval Fired </b>"
// clr=setTimeout(logKaro, 2000);
// setInterval(logKaro, 2000);
// use clearInterval(clr)/clearTimeout(clr) to cancel setInterval/setTimeout
// localStorage.removeItem('name')
// localStorage.clear();

// json
// obj={name:"Sindhuja",length:1, a: {this:"that"}}
// jso=JSON.stringify(obj);
// console.log( typeof jso);
// console.log(jso);
// parsed =JSON.parse('{"name":"Sindhuja","length":1, "a": {"this":"that"}}');
// console.log(parsed);
// ECMA Script is a standard version through which javaScript is handled

